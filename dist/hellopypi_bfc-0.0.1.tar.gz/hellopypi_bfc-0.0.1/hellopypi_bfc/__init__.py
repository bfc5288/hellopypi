__import__("pkg_resources").declare_namespace(__name__)

def hello_world():
    print('Greetings starshine, the earth says hello')
